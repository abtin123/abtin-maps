from django.apps import AppConfig


class OrganizationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.organization'
    label = 'organization'
    verbose_name = 'سازمان (شرکت/شعبه/انبار)'
