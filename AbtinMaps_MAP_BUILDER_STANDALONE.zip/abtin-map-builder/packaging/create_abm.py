from __future__ import annotations
import hashlib, json, sqlite3, tempfile, zipfile
from pathlib import Path

FORBIDDEN=({'tile','tiles','pmtiles','mbtiles','style.json','render_cache'})

def create_abm(staging: Path, output: Path, country: str, source: Path, stats: dict,
                bbox: tuple[float, float, float, float] | None,
                region: dict | None = None) -> Path:
    """Package a staged vector/poi/search/routing tree into a single tile-free
    `.abm` archive.

    ``bbox`` is required by the app's release manifest (it draws the region's
    footprint on the World Overview and decides whether "این منطقه دانلود
    نشده است" should show). A build with genuinely no geometry (an empty test
    fixture) may pass ``bbox=None``, but real builds should always have one -
    verify_abm raises if it's missing so a broken/empty build can't ship
    silently.

    ``region`` is set only when this archive is one part of a country that
    was split geographically (see build_abm.py --regions): it carries the
    parent country code plus the region's own code/names so the release
    manifest can group them correctly.
    """
    metadata={
        "country": country.upper(),
        "format": "ABM",
        "version": 3,
        "tiles": False,
        "style": "external",
        "renderer": "app",
        "search": True,
        "routing": True,
        "source": source.name,
        "bbox": list(bbox) if bbox is not None else None,
        "region": region,
        "stats": stats,
    }
    (staging/'metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    files=[p for p in staging.rglob('*') if p.is_file() and p.name not in {'manifest.json'}]
    manifest={"format":"ABM","files":{str(p.relative_to(staging)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
    (staging/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
        for p in sorted(staging.rglob('*')):
            if p.is_file(): z.write(p,p.relative_to(staging).as_posix())
    return output

def verify_abm(path: Path, *, require_bbox: bool = True) -> dict:
    required={'metadata.json','vector/index.json','vector/terrain.bin','poi/poi.sqlite','search/search.sqlite','routing/graph.sqlite'}
    with zipfile.ZipFile(path) as z:
        names=set(z.namelist()); missing=sorted(required-names)
        for layer in ('roads','buildings','landuse','water','boundaries','places'):
            if not any(n.startswith(f'vector/{layer}/') and n.endswith('.bin') for n in names):
                missing.append(f'vector/{layer}/*.bin')
        bad=[n for n in names if any(x in n.lower() for x in FORBIDDEN)]
        if missing or bad: raise ValueError(f"Invalid ABM: missing={missing}, forbidden={bad}")
        meta=json.loads(z.read('metadata.json'))
        assert meta['tiles'] is False and meta['style']=='external'
        if require_bbox and not meta.get('bbox'):
            raise ValueError(f"Invalid ABM: {path} has no bbox in metadata.json "
                              f"(required for the release manifest / World Overview coverage check)")

        # Existence of routing/graph.sqlite is not sufficient. A previously
        # published ABM could contain a zero-row graph while all vector files
        # were valid, making offline maps render but routing fail later. Reject
        # that archive at build time instead of shipping a broken atlas.
        with tempfile.NamedTemporaryFile(suffix='.sqlite', delete=False) as tmp:
            tmp.write(z.read('routing/graph.sqlite'))
            graph_path = Path(tmp.name)
        try:
            db = sqlite3.connect(graph_path)
            try:
                tables = {r[0] for r in db.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name IN ('nodes','edges')"
                )}
                if not {'nodes', 'edges'} <= tables:
                    raise ValueError(f"Invalid ABM: {path} routing/graph.sqlite is missing nodes/edges tables")
                nodes = int(db.execute('SELECT COUNT(*) FROM nodes').fetchone()[0])
                edges = int(db.execute('SELECT COUNT(*) FROM edges').fetchone()[0])
                if nodes <= 0 or edges <= 0:
                    raise ValueError(
                        f"Invalid ABM: {path} routing graph is empty (nodes={nodes}, edges={edges})"
                    )
            finally:
                db.close()
        finally:
            graph_path.unlink(missing_ok=True)

        return {"ok":True,"files":len(names),"metadata":meta}
