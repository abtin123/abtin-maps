from pathlib import Path
import zipfile
from build_abm import main
from search.create_search_db import search

def test_build_and_validate(tmp_path, monkeypatch):
    out=tmp_path/'iran.abm'
    monkeypatch.setattr('sys.argv',['build_abm.py','sample/mini_country.jsonl','--country','IR','--output',str(out)])
    main()
    with zipfile.ZipFile(out) as z:
        assert 'metadata.json' in z.namelist()
        assert not any(x.lower().endswith(('.pmtiles','.mbtiles')) or 'tile' in x.lower() for x in z.namelist())
        assert 'vector/roads.bin' in z.namelist()

def test_search_normalization(tmp_path):
    from search.create_search_db import create_search_db
    p=tmp_path/'search.sqlite'
    create_search_db(p,[{'id':1,'name':'','name_fa':'بیمارستان','name_en':'Hospital','category':'hospital','latitude':35.7,'longitude':51.4}],[],[])
    assert search(p,'بيمارستان')[0]['id']==1
