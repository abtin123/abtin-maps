# Abtin Maps ABM Builder

A tile-free, offline-first pipeline that converts a country OSM PBF into `country.abm`. It does not create raster/vector tiles, PMTiles, MBTiles, tile pyramids, styles, render caches, or a world overview. Styling and rendering remain Flutter application responsibilities.

## Output layout

```text
metadata.json
vector/{roads,buildings,landuse,water,boundaries,places,terrain}.bin
poi/poi.sqlite
search/search.sqlite
routing/graph.bin
manifest.json
```

`*.bin` vector files use a small versioned stream format: `ABMV1\\n`, followed by big-endian 32-bit length-prefixed UTF-8 JSON records. This is deliberately simple to implement in Dart while retaining streaming and forward compatibility. `graph.bin` uses `ABMGRAPH1\\n` followed by a length-prefixed JSON graph payload. Production deployments can replace the payload codec without changing the archive contract.

## Build

Python 3.11 is required. Install dependencies and build from an OSM PBF:

```bash
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python build_abm.py iran.osm.pbf --country IR --output dist/iran.abm
```

For deterministic smoke tests, the CLI also accepts the included `.jsonl` fixture format. Every input entity is one JSON object with `kind` (`node`, `way`, or `relation`), `id`, tags, and geometry/node IDs as appropriate.

The builder logs five stages, fails fast on malformed data, validates required members and metadata, and emits no tile-related files. `terrain.bin` is an empty valid stream unless a future DEM extractor is explicitly added; no terrain is fabricated from OSM.

## Extracted data

Roads include the requested highway classes and raw names, multilingual names, one-way, bridge, tunnel, maxspeed, access, and road class. Building polygons include type and levels. Landuse, water/coastline, administrative boundaries, places, and the requested amenity/shop/tourism/transport POIs are extracted. Search SQLite contains normalized Persian fields, FTS5, and RTree spatial indexing. The routing graph contains directed edges, distance, class, speed, access, one-way behavior, and relation-derived turn-restriction records.

## Flutter boundary

The app should unzip/read the archive, build any device-specific render cache outside the archive, and render features according to app-owned styles. `metadata.json` explicitly declares `tiles: false`, `style: external`, `renderer: app`, `search: true`, and `routing: true`.

## Validation and CI

```bash
python packaging/verify_abm.py dist/iran.abm
pytest -q
```

GitHub Actions runs syntax compilation and the sample build/test path. Large PBF files should be supplied through an artifact or release workflow rather than committed to Git.

## Weekly updates and large countries

`.github/workflows/weekly-build.yml` runs every Monday and can also be started manually with an ISO country code and current PBF URL. It rebuilds the country from the latest OSM PBF, validates the ABM, and publishes artifacts. The resulting archive can be split without changing its bytes:

```bash
python packaging/split_abm.py split dist/IR.abm --output dist/IR-parts --part-size-gib 1.8
python packaging/split_abm.py join dist/IR-parts/manifest.json --output dist/IR-restored.abm
```

Every part and the reassembled archive are protected by SHA-256 checksums. This is a delivery split only; no map tiles or tile pyramid are created.

## Incremental updates

When a previous archive is available, generate a chunk patch instead of forcing every device to download the complete country archive:

```bash
python packaging/create_patch.py old/IR.abm dist/IR.abm \
  --code IR --output dist/IR-patch --chunk-size-mib 4
```

The command writes `IR.abmpatch.json`, `IR.abmpatch.bin`, and `patch-descriptor.json`. Add the descriptor under the region's `patch` field in the published catalog. The descriptor uses the exact schema consumed by the Flutter updater. The app applies the patch only when the installed archive SHA-256 equals `base_sha256`; otherwise it safely falls back to the normal full/part download.
