#!/usr/bin/env python3
from __future__ import annotations
import argparse, shutil, tempfile
from pathlib import Path
from abm_builder.core import setup_logging, write_records, LOG
from extractors.loader import load, extract_all
from search.create_search_db import create_search_db
from routing.graph_builder import build_graph
from packaging.create_abm import create_abm, verify_abm

def main():
    ap=argparse.ArgumentParser(description='Build a tile-free Abtin Maps ABM country archive')
    ap.add_argument('input',type=Path,help='OSM .pbf or test .jsonl input'); ap.add_argument('-o','--output',type=Path,required=True)
    ap.add_argument('--country',required=True,help='ISO-3166 alpha-2 country code'); ap.add_argument('--verbose',action='store_true')
    args=ap.parse_args(); setup_logging(args.verbose)
    if args.output.suffix.lower()!='.abm': raise SystemExit('Output must end with .abm')
    work=Path(tempfile.mkdtemp(prefix='abm-build-'))
    try:
        LOG.info('[1/5] Loading OSM input: %s',args.input); data=load(args.input)
        LOG.info('[2/5] Extracting vector features'); all_data=extract_all(data)
        for name in ('roads.bin','buildings.bin','landuse.bin','water.bin','boundaries.bin','places.bin'):
            p=work/'vector'/name; p.parent.mkdir(parents=True,exist_ok=True); write_records(p,all_data[name])
        # terrain is intentionally raw/empty when no DEM is supplied; no render data is invented.
        write_records(work/'vector'/'terrain.bin',[])
        LOG.info('[3/5] Building POI and FTS5/RTree databases'); create_search_db(work/'search'/'search.sqlite',all_data['poi'],all_data['places.bin'],all_data['roads.bin'])
        create_search_db(work/'poi'/'poi.sqlite',all_data['poi'],[],[])
        LOG.info('[4/5] Building routing graph'); graph_stats=build_graph(data.ways,data.relations,work/'routing'/'graph.bin')
        LOG.info('[5/5] Packaging and validating ABM'); stats={k:len(v) for k,v in all_data.items() if isinstance(v,list)}; stats['routing']=graph_stats
        create_abm(work,args.output,args.country,args.input,stats); result=verify_abm(args.output)
        LOG.info('ABM ready: %s (%d files)',args.output,result['files'])
    except Exception:
        LOG.exception('ABM build failed'); raise
    finally: shutil.rmtree(work,ignore_errors=True)
if __name__=='__main__': main()
