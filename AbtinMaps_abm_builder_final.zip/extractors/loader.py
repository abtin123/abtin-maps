from __future__ import annotations
import json
from pathlib import Path
from typing import Any
from .osm import roads, buildings, landuse, water, boundaries, places, pois

class Dataset:
    def __init__(self): self.nodes=[]; self.ways=[]; self.relations=[]


def load_jsonl(path: Path) -> Dataset:
    d = Dataset()
    for line in path.open(encoding="utf-8"):
        if not line.strip(): continue
        obj = json.loads(line); (d.nodes if obj.get("kind") == "node" else d.ways if obj.get("kind") == "way" else d.relations).append(obj)
    return d


def load(path: Path) -> Dataset:
    if path.suffix.lower() in {".jsonl", ".json"}: return load_jsonl(path)
    try:
        import osmium
    except ImportError as e:
        raise RuntimeError("PBF input requires osmium; install requirements.txt") from e
    d = Dataset()
    class Handler(osmium.SimpleHandler):
        def node(self, o): d.nodes.append(o)
        def way(self, o): d.ways.append(o)
        def relation(self, o): d.relations.append(o)
    Handler().apply_file(str(path), locations=True)
    return d


def extract_all(dataset: Dataset) -> dict[str, list[dict[str, Any]]]:
    return {
        "roads.bin": list(roads(dataset.ways)),
        "buildings.bin": list(buildings(dataset.ways)),
        "landuse.bin": list(landuse(dataset.ways)),
        "water.bin": list(water(dataset.ways)),
        "boundaries.bin": list(boundaries(dataset.ways, dataset.relations)),
        "places.bin": list(places(dataset.nodes, dataset.ways)),
        "poi": list(pois(dataset.nodes, dataset.ways)),
    }
